import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Cube3D } from './components/Cube3D';
import { CUBE_SIZE, CUBE_COLORS, INITIAL_CUBE_COUNT, SPAWN_Y, SPEED_THRESHOLDS, WIN_SCORE } from './constants';
import { CubeData, ParticleData, GameState } from './types';

// Helper to get random number in range
const randomRange = (min: number, max: number) => Math.random() * (max - min) + min;

export default function App() {
  const [score, setScore] = useState(0);
  const [gameState, setGameState] = useState<GameState>(GameState.PLAYING);
  
  // We use refs for the game loop data to avoid closure staleness and reduce React render overhead
  // although we sync to state for rendering.
  const cubesRef = useRef<CubeData[]>([]);
  const particlesRef = useRef<ParticleData[]>([]);
  const requestRef = useRef<number>();
  const scoreRef = useRef(0);
  
  // We need a state variable to trigger re-renders so the user sees the movement
  const [, setTick] = useState(0);

  // Initialize Cubes
  const initCubes = useCallback(() => {
    const newCubes: CubeData[] = [];
    const windowWidth = window.innerWidth;
    
    for (let i = 0; i < INITIAL_CUBE_COUNT; i++) {
      newCubes.push({
        id: Math.random(),
        x: randomRange(0, windowWidth - CUBE_SIZE),
        y: randomRange(SPAWN_Y, -CUBE_SIZE * 2), // Scatter initial positions high up
        rotX: randomRange(0, 360),
        rotY: randomRange(0, 360),
        rotZ: randomRange(0, 360),
        speedX: 0,
        speedY: 0, // Will be set by game logic based on score
        speedRotX: randomRange(1, 3),
        speedRotY: randomRange(1, 3),
      });
    }
    cubesRef.current = newCubes;
  }, []);

  const resetGame = () => {
    setScore(0);
    scoreRef.current = 0;
    setGameState(GameState.PLAYING);
    cubesRef.current = [];
    particlesRef.current = [];
    initCubes();
  };

  useEffect(() => {
    initCubes();
  }, [initCubes]);

  // Handle Cube Destruction
  const destroyCube = (cubeId: number) => {
    if (gameState === GameState.WON) return;

    const cubeIndex = cubesRef.current.findIndex(c => c.id === cubeId);
    if (cubeIndex === -1) return;

    const cube = cubesRef.current[cubeIndex];

    // Create Particles
    const colors = Object.values(CUBE_COLORS);
    const newParticles: ParticleData[] = [];
    
    // Explosion center
    const centerX = cube.x + CUBE_SIZE / 2;
    const centerY = cube.y + CUBE_SIZE / 2;

    for (let i = 0; i < 16; i++) {
      newParticles.push({
        id: Math.random(),
        x: centerX,
        y: centerY,
        color: colors[Math.floor(Math.random() * colors.length)],
        vx: randomRange(-10, 10),
        vy: randomRange(-10, 10),
        life: 1.0,
        size: randomRange(5, 15)
      });
    }

    particlesRef.current = [...particlesRef.current, ...newParticles];

    // Reset Cube Position (Respawn)
    // Instead of removing, we immediately recycle it to top to maintain density
    cube.y = SPAWN_Y;
    cube.x = randomRange(0, window.innerWidth - CUBE_SIZE);
    
    // Increment Score
    const newScore = scoreRef.current + 10; // +10 points per click to make 1000 achievable with ~100 clicks
    scoreRef.current = newScore;
    setScore(newScore);

    if (newScore >= WIN_SCORE) {
      setGameState(GameState.WON);
    }
  };

  // Game Loop
  const animate = useCallback(() => {
    if (gameState === GameState.WON) {
        // Just render static background or simple idle animation if needed, 
        // but for now we stop updating physics to freeze/show win screen
        // actually, let's keep particles moving but stop cubes falling?
        // The prompt says "game zeros" (resets) after the phrase.
        // Let's stop the loop logic but keep rendering.
    } else {
        const windowHeight = window.innerHeight;
        const windowWidth = window.innerWidth;
        const currentScore = scoreRef.current;

        // Determine Speed
        let currentSpeed = 2.5;
        // Check thresholds in reverse to find the highest matching range
        for (let i = SPEED_THRESHOLDS.length - 1; i >= 0; i--) {
            if (currentScore >= SPEED_THRESHOLDS[i].score) {
                currentSpeed = SPEED_THRESHOLDS[i].speed;
                break;
            }
        }

        // Update Cubes
        cubesRef.current.forEach(cube => {
            cube.y += currentSpeed;
            cube.rotX += cube.speedRotX;
            cube.rotY += cube.speedRotY;

            // Boundary Check (Bottom)
            if (cube.y > windowHeight) {
                // Respawn at top
                cube.y = SPAWN_Y;
                cube.x = randomRange(0, windowWidth - CUBE_SIZE);
                cube.rotX = randomRange(0, 360);
                cube.rotY = randomRange(0, 360);
            }
        });

        // Update Particles
        for (let i = particlesRef.current.length - 1; i >= 0; i--) {
            const p = particlesRef.current[i];
            p.x += p.vx;
            p.y += p.vy;
            p.vy += 0.5; // Gravity
            p.life -= 0.02; // Fade out

            if (p.life <= 0) {
                particlesRef.current.splice(i, 1);
            }
        }
    }

    // Force React Render
    setTick(prev => prev + 1);
    
    requestRef.current = requestAnimationFrame(animate);
  }, [gameState]);

  useEffect(() => {
    requestRef.current = requestAnimationFrame(animate);
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [animate]);

  return (
    <div className="scene bg-slate-900 w-full h-screen relative overflow-hidden select-none">
      
      {/* Score Board */}
      <div className="absolute top-4 left-4 bg-black/50 backdrop-blur-sm text-white p-4 rounded-lg z-50 font-bold text-xl pointer-events-none">
        SCORE: {score}
      </div>

      {/* Cubes */}
      {gameState !== GameState.WON && cubesRef.current.map(cube => (
        <Cube3D
          key={cube.id}
          {...cube}
          onClick={() => destroyCube(cube.id)}
        />
      ))}

      {/* Particles */}
      {particlesRef.current.map(p => (
        <div
          key={p.id}
          style={{
            position: 'absolute',
            left: p.x,
            top: p.y,
            width: p.size,
            height: p.size,
            backgroundColor: p.color,
            opacity: p.life,
            transform: `scale(${p.life})`,
            pointerEvents: 'none',
          }}
        />
      ))}

      {/* Win Screen */}
      {gameState === GameState.WON && (
        <div className="absolute inset-0 flex flex-col items-center justify-center z-[100] bg-black/80">
          <h1 className="text-6xl md:text-8xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-red-500 to-pink-500 animate-pulse text-center mb-8 drop-shadow-[0_0_15px_rgba(255,255,0,0.5)]">
            PARABÉNS, CAMPEÃO!
          </h1>
          <button
            onClick={resetGame}
            className="px-8 py-4 bg-white text-black font-bold text-2xl rounded-full hover:bg-gray-200 transition-transform transform hover:scale-105 active:scale-95 shadow-lg"
          >
            Jogar Novamente
          </button>
        </div>
      )}
    </div>
  );
}