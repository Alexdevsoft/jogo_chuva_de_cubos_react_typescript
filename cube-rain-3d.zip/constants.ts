export const CUBE_SIZE = 80;
export const SPAWN_Y = -600;
export const WIN_SCORE = 1000;

// Colors requested: amarelo, azul, verde, branco, lilas, rosa
export const CUBE_COLORS = {
  front: '#FFFF00', // Amarelo
  back: '#0000FF',  // Azul
  right: '#008000', // Verde
  left: '#FFFFFF',  // Branco
  top: '#C8A2C8',   // Lilás
  bottom: '#FFC0CB' // Rosa
};

export const SPEED_THRESHOLDS = [
  { score: 0, speed: 2.5 },
  { score: 200, speed: 3.5 },
  { score: 400, speed: 4.5 },
  { score: 600, speed: 5.5 },
];

export const INITIAL_CUBE_COUNT = 6;